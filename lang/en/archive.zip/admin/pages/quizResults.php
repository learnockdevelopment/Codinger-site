<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Admin Results Translation
    |--------------------------------------------------------------------------
    */

    'quiz_result_list_page_title' => 'Quiz Result',

    'admin_quiz_result' => 'Quiz Result',
    'admin_quiz_result_list' => 'Quiz Result List',
    'admin_quiz_result_create' => 'Quiz Result Create',
    'admin_quiz_result_edit' => 'Quiz Result Edit',
    'admin_quiz_result_delete' => 'Quiz Result Delete',
];
