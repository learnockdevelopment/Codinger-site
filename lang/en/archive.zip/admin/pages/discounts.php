<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Admin Discounts
    |--------------------------------------------------------------------------
    */

    'discount_list_page_title' => 'Discounts list',
    'discount' => 'Discount',
    'title' => 'Title',
    'tags_count' => 'Tags count',
    'new_page_lead' => 'You can create a new discount.',
    'parent_name' => 'Parent Name',
    'select_parent_name' => 'choose parent name',
    'discount_count' => 'Categories count',
    'page_lists_lead' => 'List of discount. You can edit or delete any row.',
    'sub_discount' => 'Sub discount',
    'has_sub_discount' => 'Has sub discount',
    'add_sub_discount' => 'Add sub discount',
    'add' => 'Add',
    'remove' => 'Remove',
];
