<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Notifications
    |--------------------------------------------------------------------------
    */

    'all_notifications' => 'All notifications',
    'sender' => 'Sender',
    'notifications_page_lists_lead' => 'List of notifications. You can edit or delete...',
    'send_notification' => 'Send notification',
    'edit_notification' => 'Edit notification',
    'empty_notifications' => 'Empty notifications',
    'email_ignore_msg' => 'If you didnt submit this request, please ignore it.',
    'send_noticeboard' => 'Send a new notice',
    'edit_noticeboard' => 'Edit a notice',
    'post_notice' => 'Send notice',
	'receiver' => 'Receiver',
];
